const { DataTypes } = require('sequelize');
const sequelize = require('../config'); // Import your Sequelize instance
const Greayquest = require('./Greayquest');

const IciciBankStatment = sequelize.define('IciciBankStatment', {
    tranId: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    valueDate: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    transactionDate: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    transactionPostedDate: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    chequeNoRefNo: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    transactionRemarks: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    withdrawalAmt: {
        type: DataTypes.NUMBER,
        allowNull: true,
    },
    depositAmt: {
        type: DataTypes.NUMBER,
        allowNull: true,
    },
    balance: {
        type: DataTypes.NUMBER,
        allowNull: true,
    },
});


IciciBankStatment.beforeCreate((iciciBankStatement, options) => {
    // Extract utr from transactionRemarks
    const utrMatch = iciciBankStatement.transactionRemarks.match(/UTR-(\w+)/);
    if (utrMatch) {
        iciciBankStatement.utr = utrMatch[1];
    }
});

IciciBankStatment.removeAttribute('id');

Greayquest.hasMany(IciciBankStatment, { foreignKey: 'utr', sourceKey: 'utr' });
IciciBankStatment.belongsTo(Greayquest, { foreignKey: 'utr', targetKey: 'utr' });
module.exports = IciciBankStatment;